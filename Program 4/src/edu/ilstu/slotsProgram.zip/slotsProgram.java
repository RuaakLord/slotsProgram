/**
 * 
 * Created on 07/19/2023
 * 
 * ULID: dsboye1
 * Class: IT 168 
 * 
 */

package edu.ilstu;

public class slotsProgram {
    public static void main(String[] args) {
        slotsClass game = new slotsClass();
        game.startGame();
    }
}
